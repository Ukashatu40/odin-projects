NodeJS message application with CRUD operations and user authentication.
